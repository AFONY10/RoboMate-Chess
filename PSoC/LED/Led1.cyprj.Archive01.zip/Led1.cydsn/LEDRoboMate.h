#include "project.h"
#include <stdint.h>

void setLEDs(uint8_t array[]);